﻿using System;
using System.Collections.Generic;
using System.Data.SqlTypes;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataPro
{
    public class Tree<T> where T : IComparable<T>
    {
        Node _root;
        public const int NosellDays = 30;
        public const int maxitem = 50;
        public const int lownum = 5;
        class Node
        {
            public Node Right { get; set; }
            public Node Left { get; set; }
            public Dictionary<T, int> Hight = new Dictionary<T, int>();     //key T==hight x*y, val =num of items
            public T Base { get; set; } //base is size of box x*x
            public Node(T value, T hight)
            {
                this.Base = value;
                Hight.Add(hight, 0);
            }
            public override string ToString()
            {
                StringBuilder a = new StringBuilder();
                foreach (var item in Hight)
                {
                    a.Append(item);
                }
                return $"BASE-{Base}:hights and amonts-{a}";
            }
        }
        static  public  List<Tuple<T, T,DateTime>> line = new List<Tuple<T, T,DateTime>>();
        //list that hold tuple that hold 3 arguments x,y,date

        public bool BuyBoxes(T Base, T hight,int amont,bool SplitBoxType,bool LessThanAsk)
        {
            int left = amont;
            if (_root == null) return false;//empty tree
            else
            {
                Node tmp = this._root, parent = null;
                while (tmp != null)
                {
                    parent = tmp;
                    if (Base.CompareTo(tmp.Base) >= 0)//if base is existed
                    {
                        if (tmp.Hight.ContainsKey(hight)) //if it exact take it
                        {
                            left= tmp.Hight[hight] - amont;
                            tmp.Hight[hight] -= amont;

                            if (tmp.Hight[hight] <= 0)
                            {
                                if (tmp.Hight.Count == 0) Remove(Base);//if there is no  mre boxes, remove the Node and say it----------------
                                else
                                {
                                    tmp.Hight.Remove(hight);
                                    Tuple<T, T, DateTime> a;
                                    a = GetIndex(tmp.Base, hight);
                                    line.Remove(a); //remove empty hight
                                }
                                if (left > 0)
                                {
                                    if (SplitBoxType) BuyBoxes(Base, hight, left, SplitBoxType, LessThanAsk); //find next node we have permission
                                    else return false; //we dont have premission and cant find enugh boxes to sell
                                }
                            }
                            else if (tmp.Hight[hight] <= lownum) //alert that box num is getting low----------------------------------------
                                GetNewDate(Base, hight);//set new date after a sale
                            return true; //return the box---------------------
                        }
                        T tem, best = hight;
                        //if hight is only higher
                        foreach (var item in tmp.Hight)
                        {
                            if (item.Key.CompareTo(hight) > 0)//biger hight
                            {
                                tem = item.Key; //hold val to ck
                                if (tem.CompareTo(best) < 0) best = tem;//if tem bigger then hight but smoller then best take it
                                else if (best.CompareTo(hight) == 0) best = item.Key; //first item to found
                            }
                        }
                        tmp.Hight[best] -= amont; //take 1 box
                        if (tmp.Hight[best] <= 0) Remove(Base);//if there is no  mre boxes, remove the Node
                        else GetNewDate(Base, hight);//set new date after a sale if the node still above 0
                        return true;
                    }
                    if (Base.CompareTo(tmp.Base) < 0) tmp = tmp.Left; //go left  in tree
                    else tmp = tmp.Right; //go right in tree
                }
                if(left>=0 && left!=amont)
                {
                    if (LessThanAsk) return true; //get the list of boxes we could find
                    else return false; //we cant find enough  boxes 
                }
                if (left <= 0) return true; //we got all
            }
            return false;
        }
        public string  FindBox(T Base, T hight)
        {
            if (_root == null) return "the tree is empty";//empty tree
            else
            {
                Node tmp = this._root, parent = null;
                while (tmp != null)
                {
                    parent = tmp;
                    if (Base.CompareTo(tmp.Base) >= 0)//if base is existed
                    {
                        if (tmp.Hight.ContainsKey(hight)) //if it exact take it
                        {
                            tmp.Hight[hight] -= 1;
                            if (tmp.Hight[hight] <= 0)
                            {
                                if (tmp.Hight.Count == 0)
                                {
                                    Remove(tmp.Base);//if there is no  mre boxes, remove node
                                    line.Remove(GetIndex(tmp.Base, hight));
                                    return $"{tmp.Base}/{hight}" +
                                        $"\n there is no more boxes with base of{tmp.Base}";
                                }
                                else
                                {
                                    tmp.Hight.Remove(hight);
                                    Tuple<T, T, DateTime> a;
                                    a = GetIndex(tmp.Base, hight);
                                    line.Remove(a);
                                    return $"{tmp.Base}/{hight}" +
                                        $"\n but there is no more boxes of{tmp.Base} with hight of{hight}";
                                }
                            }
                            else if (tmp.Hight[hight] <= lownum) //alert that box num is getting low
                                GetNewDate(tmp.Base, hight);//set new date after a sale
                            return $"{tmp.Base}/{hight}\n" +
                                $"allert that box amount is{tmp.Hight[hight]} order more";
                        }
                        else //find  alternativ hight 
                        {
                            T tem, best = hight;
                            //if hight is only higher
                            foreach (var item in tmp.Hight)
                            {
                                if (item.Key.CompareTo(hight) > 0)//biger hight
                                {
                                    tem = item.Key; //hold val to ck
                                    if (tem.CompareTo(best) < 0) best = tem;//if tem bigger then hight but smoller then best take it
                                    else if (best.CompareTo(hight) == 0) best = item.Key; //first item to found
                                }
                            }
                            tmp.Hight[best] -= 1; //take 1 box
                            if (tmp.Hight[best] <= 0)
                            {
                                if (tmp.Hight.Count == 0)
                                {
                                    Remove(tmp.Base);
                                    return $"{tmp.Base}/{best}" +
                                            $"\n there is no more boxes with base of{tmp.Base}";
                                }//if there is no  mre boxes, remove the Node
                                else
                                {
                                    tmp.Hight.Remove(best);
                                    Tuple<T, T, DateTime> a;
                                    a = GetIndex(tmp.Base, best);
                                    line.Remove(a);
                                    return $"{tmp.Base}/{best}" +
                                        $"\n but there is no more boxes of{tmp.Base} with hight of{best}";
                                }//set new date after a sale if the node still above 0
                            }
                            else  if (tmp.Hight[best] <= lownum) //alert that box num is getting low
                            {
                                GetNewDate(Base, best);//set new date after a sale
                                return $"{tmp.Base}/{best}\n" +
                                $"allert that box amount is{tmp.Hight[hight]} order more!";
                            }
                        }
                    }
                    if (Base.CompareTo(tmp.Base) < 0) tmp = tmp.Left; //go left  in tree
                    else tmp = tmp.Right; //go right in tree

                }
                return "we culd not find box with fit base";//there is no base 
            }
        }
        public void Add(T data,T hight,int amont)
        {
            if (amont > maxitem) amont = maxitem;//if u ask for more then max u take only max
            Node a = new Node(data,hight);
            if (_root == null)//empty tree
            {
                _root = a;
                a.Hight.Add(hight, amont);
                line.Add(new Tuple<T, T,DateTime>(data, hight,DateTime.Now));//add to line 
                return;
            }
            else//not empty
            {
                Node tmp = this._root, parent = null;
                while (tmp != null)
                {
                    parent = tmp;
                    if (data.CompareTo(tmp.Base) == 0)//if base is existwed
                    {
                        if (tmp.Hight.ContainsKey(hight))//if hight is true
                        {
                            tmp.Hight[hight] += amont; //if hight is exsisted just add amont
                            if (tmp.Hight[hight] > maxitem) tmp.Hight[hight] = maxitem;//if the order is bigger then max item set to max
                        }
                        else tmp.Hight.Add(hight, amont);//if hight is new add new hight
                        line.Add(new Tuple<T, T, DateTime>(data, hight, DateTime.Now));//add to line
                        return;
                    }
                    if (data.CompareTo(tmp.Base) < 0) tmp = tmp.Left; //go left  in tree
                    else tmp = tmp.Right; //go right in tree
                }
                if (data.CompareTo(parent.Base) < 0) parent.Left = a;
                else parent.Right = a;
                a.Hight.Add(hight, amont);
                line.Add(new Tuple<T, T, DateTime>(data, hight, DateTime.Now));
            }
        }
        public void Remove(T data)
        {
            if (_root == null) return; //empty tree
            Node tmp = _root, perent = null;
            while (tmp.Base.CompareTo(data) != 0)//find the number
            {
                perent = tmp;
                if (data.CompareTo(tmp.Base) < 0) tmp = tmp.Left;
                else tmp = tmp.Right;
            }
            if (tmp.Left == null && tmp.Right == null) RemoveEnd(perent, tmp);
            if (tmp.Left != null && tmp.Right != null) RemoveMid(perent, tmp);
            else RemoveOneChild(perent, tmp);
        }

        public void ScanInorder(Action<T> action) => ScanInorder(_root, action);
        private void ScanInorder(Node root, Action<T> action)
        {
            if (root == null) return;
            ScanInorder(root.Left, action);
            action(root.Base);
            ScanInorder(root.Right, action);
        }
        private void RemoveEnd(Node perent, Node tmp)
        {
            if (tmp.Base.CompareTo(perent.Base) < 0) perent.Left = null;
            else perent.Right = null;
        }
        private void RemoveOneChild(Node perent, Node tmp)
        {
            if (tmp.Left != null)
            {
                if (tmp.Base.CompareTo(perent.Base) < 0) perent.Left = tmp.Left;
                else perent.Right = tmp.Left;
            }
            else
            {
                if (tmp.Base.CompareTo(perent.Base) < 0) perent.Left = tmp.Right;
                else perent.Right = tmp.Right;
            }
        }
        private void RemoveMid(Node pernt, Node tmp)
        {
            Node tmp2 = tmp;
            pernt = tmp;
            tmp = tmp.Right;
            while (tmp.Left != null)
            {
                pernt = tmp;
                tmp = tmp.Left;
            }
            if (tmp.Right != null) //if must left has a right pointer
            {
                tmp2.Base = tmp.Base;
                RemoveMid(pernt, tmp);
            }
            else
            {
                tmp2.Base = tmp.Base;
                RemoveEnd(pernt, tmp);
            }
        }
        private void GetNewDate(T x,T y)
        {
            for (int i = 0; i < line.Count; i++)
            {
                if (line[i].Item1.CompareTo(x) == 0 && line[i].Item2.CompareTo(y) == 0)//find the index
                    line[i]=(new Tuple<T, T, DateTime>(x, y, DateTime.Now));//override him for new date after sale
            }
        }
        private Tuple<T,T,DateTime> GetIndex(T x, T y)
        {
            for (int i = 0; i < line.Count; i++)
            {
                if (line[i].Item1.CompareTo(x) == 0 && line[i].Item2.CompareTo(y) == 0)//find the index
                    return line[i];
            }
            throw new Exception("index not found");
        }
    }
}

