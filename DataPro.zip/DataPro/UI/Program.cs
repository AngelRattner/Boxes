﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.UI.Xaml;
using System.Threading;
using System.Threading.Tasks;
using DataPro;
using Boxes;
namespace UI
{
    class Program
    {
        static void Main(string[] args)
        {
            DispatcherTimer time = new DispatcherTimer();
            time.Tick += CheckToRemove;
            time.Interval = new TimeSpan(1, 0, 0, 0, 0);
            time.Start();


        }
        public string CheckToRemove()
        {
            StringBuilder a = new StringBuilder();
            for (int i = 0; i < Tree<float>.line.Count; i++)
            {
                String diff2 = (DateTime.Now - Tree<float>.line[i].Item3).TotalDays.ToString();
                if (Convert.ToInt32(diff2) >= Tree<float>.NosellDays)
                {
                    a.Append(Tree<float>.line[i]);
                    Tree<float>.line[i] = null;
                }
            }
            return a.ToString();
        }
    }
}
