﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Boxes
{
    public class Box
    {
        float  Base { get; }
        float  Hight { get; }
        public Box(float  baseX, float  hightY)
        {
            float basee = baseX * 2; 
            Base = basee; Hight = hightY;
        }
    }
}
